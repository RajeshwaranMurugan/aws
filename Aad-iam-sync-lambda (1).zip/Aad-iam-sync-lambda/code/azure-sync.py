#!/usr/bin/env python2.7

"""
This Sync lambda is designed to get all the SAML Identity providers from your AWS
accounts or organizations tree, then synchronize them with an Azure application
structure. Thereby allowing Single-SignOn capability with Azure.

"""

import uuid
import os
import sys
import base64
import copy
sys.path.insert(0, os.path.abspath('./site-packages'))
from azure.graphrbac.models.app_role import AppRole
from azure.graphrbac.models.app_role_py3 import AppRole
from azure.graphrbac.models import ApplicationUpdateParameters
from azure.common.credentials import UserPassCredentials
from azure.graphrbac import GraphRbacManagementClient
import boto3
import json
import logging
import time
import datetime


## Class definitions
class AppRoles(object):
  # Define CLASS variables
  AZURE_ROLE_LIMIT = 1200

  def __init__(self):
    logger.info('Initializing the AppRole Object')
    self.roles = []
    self.existingAzureBasedRoles  = {}

  def addRole(self, prospectiveRole):
    logger.info('Add new role object of type = %s' % (str(type(prospectiveRole))))
    if ( str(type(prospectiveRole)) == "<class 'azure.graphrbac.models.app_role_py3.AppRole'>"):
      logger.info('Offered a AZURE sourced role = %s' % (str(type(prospectiveRole))))

      if prospectiveRole.is_enabled:
        # Record the existing  role and state
        self.existingAzureBasedRoles[prospectiveRole.display_name] = prospectiveRole.is_enabled
        prospectiveRole.is_enabled = False
        self.insert_role(prospectiveRole)
        logger.info('AZURE sourced role added as disabled = %s' % (str(type(prospectiveRole))))
      else:
        #Role is disabled in Azure so we will drop it.
        logger.warn('AZURE sourced Role is disabled in Azure so we will drop it [%s]' % (prospectiveRole.display_name))

    elif (str(type(prospectiveRole)) == "<class 'dict'>"):
      logger.info('Adding a new AWS sourced role = %s' % (str(type(prospectiveRole))))
      # Azure AppRole type https://docs.microsoft.com/en-us/python/api/azure-graphrbac/azure.graphrbac.models.approle?view=azure-python
      self.insert_role(AppRole(id=prospectiveRole['id'],
                          allowed_member_types=["User"],
                          description=str(prospectiveRole['description']),
                          display_name=str(prospectiveRole['display_name']),
                          is_enabled=True,
                          value=str(prospectiveRole['value'])))

    else:
      logger.warning('Not a valid object type, cannot add = %s' % (str(type(prospectiveRole))))
      return False

  def can_add_roles(self):
    """ This function will test if we have the maximum number of rolls we can add as dictated by the AZURE_ROLE_LIMIT"""
    if (len(self.roles) + 1) < self.AZURE_ROLE_LIMIT:
      return True
    else:
      return False

  def insert_role(self, prospectiveRole):
    """ Insert the role if the display_name does not exist, set it to True if it does and ensure msiam_access is first. """
    for role in self.roles:
      if prospectiveRole.display_name == role.display_name:
        logger.info('We already have a matching Role for %s, so we will set it to True and move on.' % (str(prospectiveRole.display_name)))
        role.is_enabled=True
        return True

    if prospectiveRole.description == 'msiam_access':
      logger.info('Special MSIAM_ACCESS role found %s, must preserve and put first.' % (str(prospectiveRole.display_name)))
      prospectiveRole.is_enabled = True
      self.roles.insert(0, prospectiveRole)
      return True
    else:
      if self.can_add_roles():
        logger.info('Is new will ADD %s.' % (str(prospectiveRole.display_name)))
        self.roles.append(prospectiveRole)
        return True
      else:
        logger.info('This role is new but you have exceeded the Azure Max Role Limit of [%s] will NOT ADD [%s].' % (self.AZURE_ROLE_LIMIT, str(prospectiveRole.display_name)))
        return False


  def create_role(self, role, account, policy):
    """ This function will construct a role based on parameeters received. """
    logger.info('Creating a new AWS sourced role.')
    label = '[{}] {}'.format(account, role['RoleName'])
    newRole = {}
    newRole['description'] = role['Description'] if 'Description' in role else role['RoleName']
    newRole['display_name'] = label
    newRole['allowed_member_types'] = ['User']
    newRole['id'] = str(uuid.uuid5(uuid.NAMESPACE_DNS, label))
    newRole['is_enabled'] = True
    newRole['value'] = '{},{}'.format(role['Arn'], policy['Principal']['Federated'])
    self.addRole(newRole)

  def get_roles(self):
    return self.roles

  def haschanged(self):
    """ Has the manifest changed at all """
    # Is there a difference in Azure vs AWS Roles ?
    logger.info(self.existingAzureBasedRoles)
    if len(self.existingAzureBasedRoles.keys()) == len(self.roles):
      logger.info("There are the same number of old roles [%s] vs new roles [%s]." % (len(self.existingAzureBasedRoles.keys()), len(self.roles)))
      # Are all the roles of the same state
      for role in self.roles:
        if role.is_enabled == self.existingAzureBasedRoles[role.display_name]:
          logger.info("Role [%s] stays the same." % (role.display_name))
        else:
          logger.info("Role [%s] has changed." % (role.display_name))
          return True
      logger.info("Have evaluated all the roles and nothing has changed.")
      return False
    else:
      logger.warning("There are NOT the same number of old roles [%s] vs new roles [%s]." % (len(self.existingAzureBasedRoles.keys()), len(self.roles)))
      return True

  def __str__(self):
    returnDict = {}
    returnDict['app_roles']  = []
    for role in self.roles:
      returnDict['app_roles'].append(str(role))
    return json.dumps(returnDict, sort_keys=True, indent=2)

  def count(self):
    return len(self.roles)


## Entrypoint
def lambda_handler(event, context):
  logger.warning(">>>>>>> BEGIN the Azure-sync function.")
  masterRoles = AppRoles()

  #1. Test the environment and ensure it works
  logger.warning("STEP 1: Test the Environment.")
  BACKUPBUCKET = os.environ.get('S3BUCKET')
  ACCOUNTLIST = os.environ.get('ACCOUNTLIST',"")
  ASSROLENAME = os.environ.get('ASSROLENAME')
  IDENTITYPROVNAME = os.environ.get('IDENTITYPROVNAME')

  #2. Get all the secrets from secrets manager
  logger.warning("STEP 2: Retrieve the secrets")
  azureObjectId = grabSecret(os.environ.get('SECRETARNTOOBJECTID'))
  azureTenant = grabSecret(os.environ.get('SECRETARNTOTENANT'))
  azureUsername = grabSecret(os.environ.get('SECRETARNTOUSERNAME'))
  azurePassword = grabSecret(os.environ.get('SECRETARNTOPASSWORD'))

  #3. Get the Manifest from Azure
  logger.warning("STEP 3: Retrieve the Azure manifest.")
  azureManifest = getAzureManifest(azureObjectId, azureTenant, azureUsername, azurePassword)

  #4. Process through the appRoles from the Azure Manifest
  logger.warning("STEP 4: Import the manifest roles.")
  for role in azureManifest.app_roles:
    masterRoles.addRole(role)

  #5. Retrieve all the account numbers from Organizations
  logger.warning("STEP 5: Retrieve the Account numbers from the Organization.")
  if ACCOUNTLIST == "":
    accountList = getAccountList()
  else:
    accountList = [x.strip() for x in ACCOUNTLIST.split(',')]

  #6. Jump into each account and return the IAM Roles
  logger.warning("STEP 6: Retrieve the SAML Roles from each account.")
  getAccountRoles(accountList, ASSROLENAME, masterRoles, IDENTITYPROVNAME)
  logger.info(masterRoles)

  if masterRoles == 0:
    logger.critical("No applicable SAML roles found")
    return False
  else:
    logger.info("Found the following roles to add ==>  %s ." % (masterRoles))

  #7. Update with the Newly discovered roles.
  logger.warning("STEP 7: Upload all New manifest roles.")
  logger.info('Role to update are: {}'.format(masterRoles))
  if masterRoles.haschanged():
    logger.warning("Manifest has changed so will backup and update.")
    updateAzureManifest(azureObjectId, azureTenant, azureUsername, azurePassword, azureManifest, masterRoles.get_roles(),BACKUPBUCKET)
  else:
    logger.warning("Manifest has NOT changed so will skip update.")
    return True


def updateAzureManifest(objectId, tenant, username, password, azureManifest, rolesList, BACKUPBUCKET):
  """ This subroutine will patch the manifest changes to Azure """
  try:
    credentials = UserPassCredentials(
        username, password, resource='https://graph.windows.net')
    graphrbac_client = GraphRbacManagementClient(credentials, tenant)
    logger.info('Successfully logged into Azure with user [%s] ' % (username))

  except Exception as e:
    logger.critical(
      "Error authenticating to Azure with user [%s], error was [%s]" % (username, e))
    raise Exception("Error authenticating to Azure with user [%s], error was [%s]" % (username, e))

  try:
    #ApplicationUpdateParameter class https://docs.microsoft.com/en-us/python/api/azure-graphrbac/azure.graphrbac.models.applicationupdateparameters?view=azure-python
    appPatch = ApplicationUpdateParameters(app_roles=rolesList)

    # Generate an before doc
    beforeManifestJson = decodeManifestToJson(azureManifest)

    logger.info("BEFORE >> %s" % (beforeManifestJson))

    # applications.patch method https://docs.microsoft.com/en-us/python/api/azure-graphrbac/azure.graphrbac.operations.applications_operations.applicationsoperations?view=azure-python#patch-application-object-id--parameters--custom-headers-none--raw-false----operation-config-
    graphrbac_client.applications.patch(objectId, appPatch)
    logger.info('Patched the principal: %s with [%s]' % (objectId, str(appPatch.app_roles[0])))

    # Generate an after doc
    afterManifestJson = decodeManifestToJson(getAzureManifest(objectId, tenant, username, password))
    logger.info("AFTER >> %s" % (afterManifestJson))

    # Upload both manifests to s3
    prefix = datetime.datetime.now().strftime('%Y/%m/%d/%H/%M/%S')
    backupToS3(BACKUPBUCKET,"%s/beforeManifestFile%s.json" % (prefix, objectId),beforeManifestJson)
    backupToS3(BACKUPBUCKET,"%s/afterManifestFile%s.json" % (prefix, objectId),afterManifestJson)

  except Exception as e:
    logger.critical('Error retrieving the Azure principal %s' % (e))
    raise Exception('Error retrieving the Azure principal %s' % (e))


def backupToS3(bucket, name, jsonData):
  """ This function will backup Json data to a file in s3,  or die trying."""
  try:
    # Create an S3 client
    s3 = boto3.client('s3')

    # Upload file
    s3.put_object(
      Body=jsonData,
      Bucket=bucket,
      Key=name
    )
  except Exception as e:
    logger.critical('Error uploading file [%s] to bucket [%s] with contents [%s], error was [%s].' % (name, bucket, jsonData, e))
    return False
  else:
    logger.info('Uploaded file [%s] to bucket [%s].' % (name, bucket))
    return True


def getAzureManifest(objectId, tenant, username, password):
  """ This subroutine will fetch the Azure manifest file and return the json object. """
  try:
    credentials = UserPassCredentials(
        username, password, resource='https://graph.windows.net')
    graphrbac_client = GraphRbacManagementClient(credentials, tenant)
    logger.info('Successfully logged into Azure with user [%s] ' % (username))

  except Exception as e:
    logger.critical(
        'Error authenticating to Azure with user [%s], error was [%s]' % (username, e))
    raise Exception("Error authenticating to Azure with user [%s], error was [%s]" % (username, e))
  try:
    # Azure Applications.Get method https://docs.microsoft.com/en-us/python/api/azure-graphrbac/azure.graphrbac.operations.applications_operations.applicationsoperations?view=azure-python#get-application-object-id--custom-headers-none--raw-false----operation-config-
    principal = graphrbac_client.applications.get(application_object_id=objectId)
    logger.info('Found the following principal: %s' %(json.dumps(str(principal))))
    return principal

  except Exception as e:
    logger.critical('Error retrieving the Azure principal %s' % (e))
    raise Exception('Error retrieving the Azure principal %s' % (e))


def decodeManifestToJson(manifestObj):
  """ This function will take the manifest and flatten it into a json structure"""
  logger.info("decodeManifestToJson() called.")
  returnDict = copy.copy(manifestObj.__dict__)
  returnDict['app_roles'] =  []
  for role in manifestObj.app_roles:
    returnDict['app_roles'].append(role.__dict__)
  return json.dumps(returnDict, sort_keys=True, indent=4)


def grabSecret(secretArn):
  """ This function will retrieve and decode secrets from Secrets manager by its ARN """
  session = boto3.session.Session()
  client = session.client(
      service_name='secretsmanager'
  )
  try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secretArn
    )
  except Exception as e:
    logger.critical("Unable to retrieve the secret [%s], with the error [%s]" % (secretArn, e))
    raise Exception(
        "Unable to retrieve the secret [%s], with the error [%s]" % (secretArn, e))

  else:
    # Decrypts secret using the associated KMS CMK.
    # Depending on whether the secret is a string or binary, one of these fields will be populated.
    if 'SecretString' in get_secret_value_response:
        return get_secret_value_response['SecretString']
    else:
        return base64.b64decode(get_secret_value_response['SecretBinary'])


def getAccountList():
  """ This subroutine will retrieve all the account numbers in the organization """
  accountlist = []
  session = boto3.session.Session()
  try:
    client = session.client(
        service_name='organizations'
    )
    response = client.list_accounts()
  except Exception as e:
    logger.critical("Unable to retrieve the accounts from the organization, with the error [%s]" % (e))
    raise Exception(
        "Unable to retrieve the accounts from the organization, with the error [%s]" % (e))
  else:
    for Account in response['Accounts']:
        logger.info("Account %s found." % (Account['Id']))
        accountlist.append(Account['Id'])
    return accountlist


def getAccountRoles(accountList, roleName, masterRoles, identityProviderRole):
  for account in accountList:
    try:
      logger.info("Attempting to assume role %s in account %s." % (roleName, account))
      client = boto3.client('sts')
      assumed_role_object = client.assume_role(
          RoleArn="arn:aws:iam::%s:role/%s" % (account, roleName),
          RoleSessionName="AssumeRoleSession1"
      )
      credentials = assumed_role_object['Credentials']
    except Exception as e:
      logger.warning("Unable to assume role %s in account %s, with the error [%s]" % (
          roleName, account, e))
    else:
      iam_account = boto3.client(
        'iam',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken']
      )

      paginator_list_roles = iam_account.get_paginator('list_roles')
      #Roles may exceed a page  so loop through all pages.
      for roles_page in paginator_list_roles.paginate():
        for role in roles_page['Roles']:
          if 'AssumeRolePolicyDocument' in role.keys():
            logger.info("Looking for a SAML role named [%s]." % (identityProviderRole))
            for policy in role['AssumeRolePolicyDocument']['Statement']:
              if "sts:AssumeRoleWithSAML" in str(policy):
                logger.info("Found %s role to be SAML one." % (role['RoleName']))
                if 'Federated' in policy['Principal']:
                  logger.info("Looking in [%s] for [%s]." % (policy['Principal']['Federated'], identityProviderRole))
                  if identityProviderRole in policy['Principal']['Federated']:
                    logger.info("Found policy %s -- %s" % (policy['Principal']['Federated'], role["Arn"]))
                    masterRoles.create_role(role, account, policy)


# Determine if we are running local or from a lambda function.
if __name__ == '__main__':
    # Setup logging
    logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
    logger = logging.getLogger()
    logger.setLevel(os.environ.get('LOGLEVEL', 'DEBUG').upper())
    logger.warning('Running in non-lambda local mode.')

    # Setup local environment
    os.environ['SECRETARNTOPASSWORD'] = 'arn:aws:secretsmanager:ap-southeast-2:936415716333:secret:/azuread-sync/password-67u8NB'
    os.environ['SECRETARNTOTENANT'] = 'arn:aws:secretsmanager:ap-southeast-2:936415716333:secret:/azuread-sync/tenant-36Y3E3'
    os.environ['SECRETARNTOUSERNAME'] = 'arn:aws:secretsmanager:ap-southeast-2:936415716333:secret:/azuread-sync/username-1DkBnP'
    os.environ['SECRETARNTOOBJECTID'] = 'arn:aws:secretsmanager:ap-southeast-2:936415716333:secret:/azuread-sync/objectid-Z5YnB5'
    os.environ['ASSROLENAME'] = 'OrganizationAccountAccessRole'
    os.environ['S3BUCKET'] = 'backup-azure-bucket'

    # Test that the credentials are set.
    try:
        run_session = boto3.session.Session(
            profile_name=os.environ.get('AWS_DEFAULT_PROFILE'))
        client = run_session.client('sts')
        response = client.get_caller_identity()
        logger.info("Connected to AWS as [%s]" % (response['Arn']))
    except Exception as e:
        logger.critical(
            "Unable to authenticate to account, error [%s]" % (str(e)))
    else:
        logger.info("Successfully authenticated to account.")
        event = {}
        context = {}
        lambda_handler(event, context)

else:
    # Setup logging
    logger = logging.getLogger()
    logger.setLevel(os.environ.get('LOGLEVEL', 'DEBUG').upper())
    logger.warning('Running in lambda aws mode.')
    local_run = False

    try:
        run_session = boto3.session.Session()
        client = run_session.client('sts')
        response = client.get_caller_identity()
        logger.info("Connected to AWS as [%s]" % (response['Arn']))

    except Exception as e:
        logger.critical(
            "Unable to authenticate to account, error [%s]" % (str(e)))

    else:
        logger.info("Successfully authenticated to account.")
