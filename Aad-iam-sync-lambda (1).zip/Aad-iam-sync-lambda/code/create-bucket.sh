#! /bin/bash
set -e # Exit on failures

export AWS_ACCOUNTID=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'accountId' | awk -F'"' '{print $4}')
export AWS_DEFAULT_REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\" '{print $4}')

echo "Please specify an Alias to prefix a unique bucket name (alias-account-region-demosync):"
read ALIAS
export BUCKET="$ALIAS-$AWS_ACCOUNTID-$AWS_DEFAULT_REGION-demosync"

set -x
#  create the bucket
aws s3api create-bucket --bucket $BUCKET --region $AWS_DEFAULT_REGION --create-bucket-configuration LocationConstraint=$AWS_DEFAULT_REGION

# prevent public access
aws s3api  put-public-access-block --bucket $BUCKET --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# enable default encryption
aws s3api put-bucket-encryption --bucket $BUCKET --server-side-encryption-configuration '{"Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]}'
set +x
echo
echo "Take note of your deployment bucket: $BUCKET"