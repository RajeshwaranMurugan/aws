const handler = require('../handler');

handler.handler({}, null, (err, data) => {
  if (err) {
    console.error('Something went wrong', err);
  } else {
    console.log('Success', data);
  }
});
