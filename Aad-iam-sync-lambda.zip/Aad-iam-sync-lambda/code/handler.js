const AWS = require('aws-sdk');
const uuid = require('uuid/v4');

const AzureService = require('./lib/AzureService');
const AWSService = require('./lib/AWSService');


// AzureAD Configuration
let config;
let Azure;

// AWS Configuration
const backupBucket = process.env.S3BUCKET;

class NothingToDo { }

/**
 * Lamnda function entry point
 */
exports.handler = (event, context, callback) => {
  if (config) {
    processEvent(event, context, callback);
    return;
  }

  // Otherwise load configuration
  console.log('Loading configuration from SSM Parameter Store');
  loadAllConfig()
    .then((data) => {
      console.log('Successfully loaded configuration');
      config = data; // Cache config for next execution
      Azure = new AzureService(config.tennant);

      processEvent(event, context, callback);
    })
    .catch((err) => {
      console.error('Error loading configuration', err);
      callback(err);
    });
};


function processEvent(event, context, callback) {
  console.log('Begin procesing IAM Roles');

  AWSService.getAllIAMRoles()
    .then((roles) => {
      return roles.map((role) => {
        // Transform role objects to the format required by AzureAD
        return {
          allowedMemberTypes: ['User'],
          isEnabled: true,
          displayName: `${role.name} - ${role.account.name}`,
          id: uuid(), // Note: this id is only used if this role ARN isn't already in the manifest
          description: `${role.name} in the ${role.account.name} Account (${role.account.id})`,
          value: `${role.idp},${role.arn}`,
        };
      });
    })
    .then((awsRoles) => {
      return getApplicationManifest()
        .then((manifest) => {
          const aadRoles = manifest.appRoles;
          const { newRoles, delta } = computeNewRoleSet(aadRoles, awsRoles);

          if (delta < 1) {
            throw new NothingToDo();
          }

          // First save a backup of the current Manifest before making any changes
          const filename = `manifest-${new Date().toISOString()}.json`;
          return AWSService.saveFiletoS3(backupBucket, filename, JSON.stringify(manifest, null, 2))
            .then(() => {
              console.log(`Successfully saved manifest backup: S3://${backupBucket}/${filename}`);

              console.log(`About to update application with ${delta} changed roles`);
              manifest.appRoles = newRoles; // eslint-disable-line no-param-reassign
              return Azure.updateApplication(config.objectid, manifest);

              // TODO: Could clean up further and permanently remove inactive roles
            });
        })
        .then(() => {
          callback(null, 'Complete');
        });
    })
    .catch((err) => {
      if (err instanceof NothingToDo) {
        callback(null, 'Complete (nothing to do)');
        return;
      }

      console.error('Failed to Synchronize Roles', err);
      callback(err);
    });
}

function getApplicationManifest() {
  return Azure.login(config.username, config.password)
    .then(() => {
      return Azure.getApplication(config.objectid);
    });
}

function computeNewRoleSet(aadRoles, awsRoles) {
  const newRoles = aadRoles; // Start with existing roles
  let delta = 0;

  aadRoles.forEach((role) => {
    if (role.value && !roleExists(role, awsRoles)) {
      // Role removed from AWS, mark as disabled in AAD
      role.isEnabled = false; // eslint-disable-line no-param-reassign
      delta++;
    }
  });

  awsRoles.forEach((role) => {
    if (!roleExists(role, aadRoles)) {
      // New role in AWS, add to AAD
      newRoles.push(role);
      delta++;
    }
  });

  return { newRoles, delta };
}

function roleExists(role, list) {
  return list.find((item) => {
    return item.value === role.value;
  });
}

function loadAllConfig() {
  const ssm = new AWS.SSM();
  return ssm.getParameters({
    Names: [
      '/azuread-sync/tennant',
      '/azuread-sync/objectid',
      '/azuread-sync/username',
      '/azuread-sync/password',
    ],
    WithDecryption: true,
  }).promise()
    .then((data) => {
      if (data.InvalidParameters.length) {
        console.error('Some parameters were found to be invalid', data.InvalidParameters);
        throw new Error('Failed to load all required parameters from SSM Parameter Store');
      }

      const tmp = {};
      data.Parameters.forEach((item) => {
        const shortName = getShortName(item.Name);
        tmp[shortName] = item.Value;
      });
      return tmp;
    });
}

function getShortName(name) {
  return name.split('/').pop(); // get string after last slash
}

