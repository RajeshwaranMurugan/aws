#! /bin/bash
set -e # Exit on failures


export AWS_DEFAULT_REGION=`curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\" '{print $4}'`


echo "Please enter Azure AD Custom Domain:"
read TENANT
aws ssm put-parameter --type "SecureString" --name "/azuread-sync/tennant" --value "$TENANT" \
--description "Azure AD Tenant representing your organization" --overwrite


echo "Please enter AzureAD Application Object ID:"
read OBJECTID
aws ssm put-parameter --type "SecureString" --name "/azuread-sync/objectid" --value "$OBJECTID" \
--description "Azure AD Application Object ID representing AWS" --overwrite

echo "Please enter an AzureAD User - Username:"
read USERNAME
aws ssm put-parameter --type "SecureString" --name "/azuread-sync/username" --value "$USERNAME" \
--description "Azure AD Username for user with rights to update the Application Manifest" --overwrite

echo "Please enter an AzureAD User - Password:"
read -s PASSWORD
aws ssm put-parameter --type "SecureString" --name "/azuread-sync/password" --value "$PASSWORD" \
--description "Azure AD Password for user with rights to update the Application Manifest" --overwrite

echo ""
echo "Parameter creation complete.  KMS Key ARN is:"
aws kms describe-key --key-id "alias/aws/ssm" --query "KeyMetadata.Arn" --output text