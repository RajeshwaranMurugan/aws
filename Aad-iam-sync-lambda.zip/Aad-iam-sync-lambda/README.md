# AzureAD Role Sync Lambda

The source code associated with this document can be found here:
https://code.amazon.com/packages/Aad-iam-sync-lambda/trees/mainline

## Background
Many companies choose to master their corporate identities in Microsoft Active Directory, and expose these for Single-Sign-On (SSO) through Azure AD.  When using this approach with Amazon Web Services (AWS) there is a need to keep the list of roles in Azure AD in sync with the roles in AWS so that users can be correctly assigned to the roles required for them to perform their duties.

Azure AD comes with a prebuilt connector which will automatically provision AWS Roles into Azure AD, however this only works with a single AWS Account.  AWS Recommended Best Practice is for customers to run multiple AWS Accounts, and this helper function facilitates the automatic synchronization of IAM Roles to Azure AD in a multi-account AWS environment.

![Integration Diagram](docs/AAD-Sync.png "High level integration diagram for Azure AD Sync Lamba")

This Synchronization  function relies on the target AWS accounts being grouped inside an AWS Organization.  It will automatically detect all child accounts and identify the roles which are linked to a federated identity provider (AzureAD).  Identified roles are then written into the application manifest within Azure AD which makes them available to be assigned to users/groups. For safety, the Synchronization  function always saves a backup of the application manifest into S3 before making any changes to Azure AD.

Note that AWS best practice is to avoid using the AWS Organization Master Account for running workloads, and generally ensure this account is infrequently accessed. However, the exception to this is automated processes which facilitate the smooth running of the AWS Organization, of which the Synchronization Function is one.

## Initial Setup
This section assumes that your AWS accounts are not currently linked to Azure AD for federated logins.  If you already have federation with Azure AD working within your child accounts then you can skip ahead to the deployment section below. 

### Configure Azure AD

#### Step 1: Create and Enterprize Application to Represent Your AWS Accounts
1. Within the Azure Portal, navigate to Azure Active Directory
2. Select Manage "Enterprise applications", and click on "New Application"
3. In the "Add from the gallery" text box enter "AWS", and select the "Amazon Web Services (AWS)" option

   ![Application Select](docs/screenshots/aad-setup-1.png "Select the 'Amazon Web Services (AWS)' template from the application gallery")

4. Edit the application name if desired, and click "Add"
5. Navigate to view the new application via: Azure Portal > Azure Active Directory > Enterprise Applications > All Applications > (your application name: e.g. Amazon Web Services (AWS))
6. Select Manage "Single sign-on", and change "Single Sign-on Mode" to "SAML-based Sign-on"
7. (Optional) If you have previously created an Enterprise application from this gallery template then you will need to specify a valid identifier for this application

   ![Application Identifier](docs/screenshots/aad-setup-2.png "If prompted, specify a valid identifier")

8. Under "User Attributes": Check the box for "View and edit all other user attributes", then add the following two additional attributes (values are case sensitive):

   | Name            | Value                  | Namespace                              |
   | --------------- | ---------------------- | -------------------------------------- |
   | RoleSessionName | user.userprincipalname | https://aws.amazon.com/SAML/Attributes |
   | Role            | user.assignedroles     | https://aws.amazon.com/SAML/Attributes |

   ![Additional Attributes](docs/screenshots/aad-setup-3.png "Additional attributes must be specified to support federation with AWS")

   > Note, this assumes that users are directly created on your AAD tenant. If you are using a Windows Live user, RoleSessionName must be set to `user.mail`. This may come up during a PoC, but for production use, you should only have users originating from your Azure AD tenant.

9. Under "SAML Signing Certificate":
    1. Ensure the certificate status is "Active"
    2. Download the "Metadata XML" as we will need this later
    3. If you don't see the download link for "Metadata XML", click "Save" and then refresh the page
10. Click "Save" to save all changes


#### Step 2: Determine the Application Object ID

The object id is a random identifier assigned to the Enterprise application by Azure AD.

1. Navigate to Azure Portal > Azure Active Directory > App Registrations > (Your application name e.g. Amazon Web Services (AWS))
2. If you don't see your application on the App Registrations page, ensure "All apps" is selected in the drop down
3. Click on "Manifest"
4. Identify the "objectid" field (usually near the bottom) and note down this value

   ![Application Object ID](docs/screenshots/aad-setup-4.png "Find the 'objectid' property within the Application Manifest JSON")

#### Step 3: Create a new User Account within Azure AD

This user will be used by the synchronization function when making update calls to Azure AD
1. Within the Azure Portal, navigate to Azure Active Directory
2. Select Manage "Users", and click on "New User"
3. Fill in the "Name" and "User name" for this user
4. Check the "Show Password" box and note the password for this user
5. Click "Create"
6. In a new browser window, naviate to https://login.microsoftonline.com and login as the new user. You will be prompted to change your password
7. Note the username and password for this user as these will be required later

   > Note that Azure AD users with the role "User" only have access to resources they "own".  At this point, the newly created user has no permissions other than login.

8. Navigate to Azure Portal > Azure Active Directory > App Registrations > (Your application name e.g. Amazon Web Services (AWS))
9. Click on "Settings", then "Owners" and "Add owner"
10. Select the user you just created and click "Select"


At this point we are done configuring everything we need within Azure AD.

### Configure AWS
This guide assumes you already have an AWS Organization created with a Master (root) account, and at least one child account.  If not, the follow this guide to get started: [Creating and Configuring and Organization](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_tutorials_basic.html).

#### Step 1: Create Identity Provider
The Identity Provider (IDP) represents AzureAD within the AWS environment.  The following steps need to be repeated within each child account of your organization to create the IDP in each account.

1. Within the AWS Console, navigate to the IAM Service
2. Click on "Identity providers", and then "Create Provider"
3. Choose "SAML" as the "Provider Type" and enter a recognizable name (e.g. AzureAD).  To keep things simple, the same name should be used in each child account
4. For "Metadata document", upload the Manifest XML file you downloaded when creating the AWS Enterprise application within AzureAD
5. Click "Verify" and then "Create"

   ![Create IDP](docs/screenshots/aws-setup-1.png "Create an IDP within AWS to represent Azure AD")

   > Note, if there are multiple child accounts within your organization, it is recommended to automate the above IDP creation via a script [using the AWS CLI](https://docs.aws.amazon.com/cli/latest/reference/iam/create-saml-provider.html).

#### Step 2: Create Initial Role(s)
Now we will create the roles which our AzureAD users will be able to assume/use.  These roles will have a *trust relationship* to the IDP we just created which tells the AWS IAM service to allow AzureAD to authenticate users into these roles.

The following steps need to be repeated within each child account of your organization for each user role you wish to have in that account.

1. Within the AWS Console, navigate to the IAM Service
2. Click on "Roles" and then "Create Role"
3. Under "Select type of trusted entity", click on "SAML 2.0 federation"
4. In the "SAML Provider" drop down, select your newly created IDP
5. Select "Allow programmatic and AWS Management Console access", and click "Next"

   ![Create IAM Role](docs/screenshots/aws-setup-2.png "Create an IAM Role with a trust relationship to the Azure AD IDP")

6. Select the Policy (permissions) you wish the new role to have.  If this is your first test, it is easiest to select the policy "Administrator Access".  The Policies attached to the role can be edited again in future if required.
7. Click "Review"
8. Enter a name for your new Role.  It is recommended to prefix the role name to indicate that this role has a trust relationship with AzureAD e.g. `AzureAD-AdminRole`

#### Step 3: Ensure OrganizationAccountAccessRole Exists in All Child Accounts
When AWS Accounts are created within an AWS Organization a AWS IAM Role is created within the child account allowing entities in the Master Account to access resources within the child account.  However, if an account was created separately and then invited into the AWS Organization later, this role will not exist.

The Synchronization function relies on this organization access role to determine the set of existing IAM roles.  If the role is missing within any of our AWS Accounts then the role will need to be created.

The CloudFormation template `deploy/organizationaccessrole.yml` can be used to create the role automatically.  Note, you will need to know the AWS Account ID of the Organization Master Account and specify this as a parameter to the template.

#### Step 4: Install and Configure AWS CLI
Later steps in this guide will use the [AWS Command Line Interface (CLI)](https://aws.amazon.com/cli/) to quickly and easily execute commands against your AWS environment.  If you already have the CLI installed and have configured the CLI with AWS Access Keys then you can skip this section.

1. Download and install the AWS CLI.  Detailed instructions are [available here](https://docs.aws.amazon.com/cli/latest/userguide/installing.html).

2. Configure the CLI with AWS Access Keys. Note that the access keys must belong to your user within the Master Account.  Detailed instructions for configuring the AWS CLI are [available here](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html#cli-quick-configuration).

   > Make sure that your CLI profile region is set to the code of the AWS region closest to you. A list of available regions is [available here](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html#concepts-available-regions).

#### Step 5: Create S3 Bucket for Function Deployment
When deploying code into AWS Lambda, the code must be built, packaged and stored into S3 before it can be loaded into AWS Lambda.  The following command can be used to create a S3 bucket within the master account which will store the packaged Lambda code before it is deployed.  Note that `<UNIQUE-BUCKET-NAME>` should be replaced with a globally unique name.

```bash
aws s3api create-bucket --bucket <UNIQUE-BUCKET-NAME>
```

> Note: Bucket names must be globally unique across all AWS accounts globally.  It is common practice to suffix the bucket name with your AWS account ID, or a random string.  For example: `lambda-code-bucket-ABC123`

## Deploy the Synchronization Function
The Synchronization Function is written in NodeJS and runs within AWS Lambda.  AWS Lambda lets you run code without provisioning or managing servers.  You pay only for the compute time you consume - there is no charge when your code is not running.  The Synchronization Function will only run for a second every 30 minutes, so using AWS Lambda provides a very cost-effective solution.

Note that the following conditions are required for the Synchronization Function to operate correctly:
* The target AWS accounts must exist within and AWS Organization
* All child accounts within the organization must have the `OrganizationAccountAccessRole` IAM Role (the Lambda function uses this role to query the roles within each account)
* the Synchronization Function must be loaded to run within the Master (Organization root) Account

![Integration Diagram](docs/AAD-Sync.png "High level integration diagram for Azure AD Sync Lamba")

The general flow of the Synchronization Function is as follows:
1. Every 30 minutes the Lambda function containing the NodeJS code is invoked
2. NodeJS code loads the Azure AD username and password securely from SSM Parameter Store
3. The AWS Organizations API is queried to get a list of all active child accounts within the organization
4. For each child account found:
    1. The Lambda function assumes the `OrganizationAccountAccessRole` role within the child account
    2. The list of IAM roles in the account is queries
    3. The list is filtered to only those roles which have a trust relationship with a SAML IDP
5. Once all relevant IAM Roles have been found, Azure AD is queries to get the latest Application Manifest JSON (which contains the existing AWS IAM roles Azure AD knows about)
6. The two role lists are compared, and if differences are found, then the Application Manifest JSON is updated to reflect the existing AWS IAM Roles
7. Finally, the Application Manifest JSON is saved back into Azure AD, and the Lambda function completes

### Step 1: Deploy the Function Configuration
The Synchronization Function requires the username and password of a user within Azure AD that has rights to update the Enterprise application representing AWS SSO.  These credentials will be stored securely within AWS Systems Manager (SSM) Parameter Store.     

The following parameters need to be created.  If you followed this guide from the beginning, then the values for these parameters were recorded during the configuration of Azure AD.

| Name | Description | Type | Example |
| ---- | ----------- | ---- | ------- |
| `/azuread-sync/tennant` | AzureAD Tennant representing your organization | SecureString | companyname.onmicrosoft.com |
| `/azuread-sync/objectid` | AzureAD Application Object ID representing AWS | SecureString | fef541df-cde9-41ad-856f-f7d0f3e1cf38 |
| `/azuread-sync/username` | AzureAD Username for user with rights to update the Application Manifest | SecureString | user@companyname.com |
| `/azuread-sync/password` | AzureAD Password for user with rights to update the Application Manifest | SecureString | A strong password |

The following steps to create each parameter should be executed within the Master Account. Ensure that you have selected your desired AWS Region before creating the parameters:
1. Within the AWS Console, navigate to the Systems Manager Service
2. Click on "Parameter Store" and then "Create Parameter"
3. Enter the "Name", "Description", "Type" and "Value" field as per the table above
4. Click "Create Parameter" 

Note that SecureString parameters are always encrypted before being stored, using keys held in AWS Key Management Service (KMS).  If the "KMS Key ID" field is left as default, then a new encryption key will be generated and stored to encrypt these parameters.  However, if a custom encryption key is desired you can create your own and use it here.  If a custom KMS key is used, the key policy must be set to allow the Lambda Function to use it for decryption.

> Alternatively, the above steps can be automated using the script `deploy/configure.sh`

### Step 2: Determine KMS Key ARN
All resources within AWS are assigned an Amazon Resource Name (ARN) which is a unique identifier for the resource. When deploying the Synchronization function, we must specify the ARN of the KMS Key used to encrypt the parameters created above.  

The following steps should be executed within the Master Account to determine the KMS Key ARN:
1. Within the AWS Console, navigate to the IAM Service
2. Click on "Encryption Keys", and if this is your first time using this service, click on "Get Started"
3. In the "Region" dropdown, select the region where your SSM Parameter Store parameters were created
4. Click on the encryption key with alias `aws/ssm` (or your desired key if a custom encruption key was used)
5. Note down the ARN of the key

### Step 3: Deploy Lambda Code to AWS
The Lambda Function to be deployed has been defined using AWS CloudFormation in the file `deploy/lambdafunction.yml`. CloudFormation allows AWS Resources to be defined in code files, and this in turn allows perfect, repeatable deployments of those resources to be executed.

We will use the AWS CLI to package and deploy the lambda function described in `deploy/lambdafunction.yml`

1. Run the following command to package the code for the AWS Lambda platform.  Note that `<S3 Bucket Name>` should be replaced with the lambda code bucket created previously. This will package the Lambda function code and upload the resulting package to the S3 bucket ready for deployment.  The CloudFormation template describing the Lambda function is then updated to reference the new package file, and saved as `lambdafunction-packaged.yml`.
   ```bash
   aws cloudformation package --template-file deploy/lambdafunction.yml --s3-bucket <S3 Bucket Name> --output-template-file deploy/lambdafunction-packaged.yml
   ```
2. Deploy the packaged code into AWS Lambda using the following command.  Note that `<KMS Key ARN>` should be replaced wtih the ARN of the KMS key used to encrypt the function parameters earlier.
   ```bash
   aws cloudformation deploy --template-file deploy/lambdafunction-packaged.yml --stack-name aad-sync-function --capabilities CAPABILITY_IAM --parameter-overrides "KMSKeyARN=<KMS Key ARN>"
   ```
3. The CloudFormation deployment will typically take a few minutes to complete.  When finished the Lambda function will be deployed and configured to automatically run every 15 minutes.

## Monitoring Function Execution
Performance and success of your Lambda function is automatically monitored by AWS by default.  Follow the following steps to view a monitoring overview:

1. Within the AWS Console, navigate to the Lambda Service
2. Click on the "Function name" of your function.  This should start with "aad-sync-function-"
3. Click on "Monitoring"
4. On this view you can see various graphs describing the function executions.  You can also click to jump to the detailed logging and metrics for the function available in AWS CloudWatch


If the Synchronization function is to be used on an on-going basis within as part of your AWS Environment, it is highly recommended to create a monitoring Alarm to automatically alert if the function execution fails.  Creation of a monitoring alarm can be easily done following the detailed instructions [available here](https://docs.aws.amazon.com/lambda/latest/dg/tutorial-scheduled-events-create-alarm.html).
